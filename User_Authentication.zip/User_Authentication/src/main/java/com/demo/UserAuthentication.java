package com.demo;

public class UserAuthentication {
	public String getUserName() {
		return "abcd";
	}
	public String getEmail() {
		return "abcd@gmail.com";
	}
	public int getPhnNum() {
		return 1234567890;
	}
	public String getPassword() {
		return "abcd@123";
	}
}
