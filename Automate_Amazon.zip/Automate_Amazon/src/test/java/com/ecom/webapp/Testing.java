package com.ecom.webapp;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;


import io.github.bonigarcia.wdm.WebDriverManager;


public class Testing {
	WebDriver wd;
	//test case is pass without any assert-by checking the flow 
	@Test(priority = 1)
	  public void register() throws InterruptedException {
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		 
		wd.findElement(By.id("nav-link-accountList")).click();
		Thread.sleep(5000);
	      wd.findElement(By.id("createAccountSubmit")).click();
	      Thread.sleep(5000);
	      wd.findElement(By.id("ap_customer_name")).sendKeys("Moni");
	      Thread.sleep(5000);
	     wd.findElement(By.id("ap_phone_number")).sendKeys("9876543210");
	      Thread.sleep(5000);
	      wd.findElement(By.id("ap_email")).sendKeys("moni@gmail.com");
	      Thread.sleep(5000);
	      wd.findElement(By.id("ap_password")).sendKeys("moni@123");
	      Thread.sleep(5000);
	     // wd.findElement(By.id("ap_password_check")).sendKeys("moni@123");
	     // Thread.sleep(5000);
	     wd.findElement(By.id("continue")).click();
	}
	
	      @Test(priority = 2)
	  public void login() throws InterruptedException {
		
		

		 wd.findElement(By.id("nav-link-accountList")).click();
		 Thread.sleep(5000);
	     wd.findElement(By.id("ap_email")).sendKeys("moni@gmail.com");
	     Thread.sleep(5000);
		  wd.findElement(By.id("continue")).click();
		  Thread.sleep(5000);
	     wd.findElement(By.id("ap_password")).sendKeys("moni@123");
	       


	  }
	  @Test(priority = 3)
	  public void addToCart() throws InterruptedException {
		  
	      	
		    System.out.println(wd.getTitle());
		    System.out.println(wd.getCurrentUrl());
		    wd.findElement(By.id("twotabsearchtextbox")).sendKeys("Samsung Galaxy Z Flip 4");
		    Thread.sleep(9000);
		    wd.findElement(By.id("nav-search-submit-button")).submit();
		    Thread.sleep(5000);
		    wd.get("https://www.amazon.in/Samsung-Galaxy-Storage-Additional-Exchange/dp/B0B8SRRGSC/ref=sr_1_3?crid=57CJGSUNY1RG&keywords=Samsung+Galaxy+Z+Flip+4&qid=1664703984&qu=eyJxc2MiOiI0LjI3IiwicXNhIjoiMy44NyIsInFzcCI6IjAuMDAifQ%3D%3D&sprefix=samsung+galaxy+z+flip+4%2Caps%2C503&sr=8-3");
		    Thread.sleep(9000);
		    wd.findElement(By.id("add-to-cart-button")).click();
		    Thread.sleep(9000);
		   
	  }
	 
	  @BeforeMethod
	    public void startbrowser()
	    {
		  WebDriverManager.chromedriver().setup();
		  	 wd=new ChromeDriver();
	      	wd.get("https://www.amazon.in/");
	      	 wd.manage().window().maximize();
	      	   
	    }



	      @AfterMethod
	    public void closeBrowser()
	    {
	        wd.close();
	    }
	  

}